/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipscmd;

/**
 *
 * @author 16031521
 */
public class Water extends Entity {
    
    
    public Water(int x, int y) {
        super(x,y);
        this.setHit(false);
        this.setType("water");
    }
}
