/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipscmd;

import java.util.ArrayList;

/**
 *
 * @author 16031521
 */
public class Ship {
    private int length;
    private ArrayList<ShipPart> shipParts;
    private boolean destroyed;
    private boolean invalid;
    private String direction;
    
    public Ship(int length, int startX, int startY, String direction) {
        this.length = length;
        shipParts = new ArrayList<ShipPart>();
        boolean invalid = false;
        int changeX = 0;
        int changeY = 0;
        this.direction = direction;
        for(int i = 0; i < length; i++) {
            switch(direction) {
                case "north":
                    changeY = -i;
                break;
                case "east":
                    changeX = i;
                break;
                case "south":
                    changeY = i;
                break;
                case "west":
                    changeX = -i;
                break;
            }
            ShipPart shipPart = new ShipPart(startX+changeX,startY+changeY);
            shipParts.add(shipPart);
        }
        destroyed = false;
    }
    
    public boolean isInvalid() {
        return invalid;
    }
    
    public int getLength() {
        return this.length;
    }
    
    public String getDirection() {
        return this.direction;
    }
    
    public boolean isDestroyed() {
        int i = 0;
        boolean destruction = true;
        do {
            if(!shipParts.get(i).getHit())
                destruction = false;
            i++;
        } while(i < length && !destroyed);
        return destruction;
    }
    
    public void destroy() {
        destroyed = true;
    }
    
    public ShipPart getPart(int part) {
        return shipParts.get(part);
    }
    public void setPart(int index, ShipPart part) {
        shipParts.set(index, part);
        assert shipParts.indexOf(part) == index && shipParts.contains(part);
    }
}
