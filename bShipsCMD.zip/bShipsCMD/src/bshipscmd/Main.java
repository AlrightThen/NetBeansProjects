/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipscmd;

import java.io.IOException;
import java.util.Scanner;


/**
 *
 * @author 16031521
 */
public class Main {
    public static void main(String[] args) throws IOException {
        BSModel room = new BSModel();
        room.generateRoom(2, 0);
        boolean win = false;
        Scanner reader = new Scanner(System.in);
        String target = "";
        do {
            System.out.println("Type in format: A1 to hit a location, type v to view the map, type n to create a new customized game, type w to cheat view the map, type s to save the game, or type nothing to end the program.");
            target = reader.nextLine();
            try {
                char x = target.charAt(0);
                if(x == 'v') {
                    System.out.println(room.toString(false));
                }
                else if(x == 'w') {
                    System.out.println(room.toString(true));
                }
                else if(x == 's') {
                    room.saveEntities();
                    System.out.println("Game saved!\n");
                }
                else if(x == 'l') {
                    if(room.loadEntities()) {
                        System.out.println("Game loaded!\n");
                    } else {
                        System.out.println("Load failed.\n");
                    }
                }
                else if(x == 'n') {
                    System.out.println("Creating new game...");
                    System.out.println("How many ships of length 2?");
                    String len = reader.nextLine();
                    int twoLen = Integer.parseInt(len);
                    while(twoLen < 0 || twoLen > 3) {
                        System.out.println("There must be between 0 and 3 ships of length 2, try again.");
                        len = reader.nextLine();
                        twoLen = Integer.parseInt(len);
                    }
                    System.out.println("How many ships of length 1?");
                    len = reader.nextLine();
                    int oneLen = Integer.parseInt(len);
                    while(oneLen < 0 || oneLen > 4) {
                        System.out.println("There must be between 0 and 4 ships of length 1, try again.");
                        len = reader.nextLine();
                        oneLen = Integer.parseInt(len);
                    }
                    if(room.generateRoom(twoLen, oneLen)) {
                        System.out.println(room.toString(false));
                    } else {
                        System.out.println("Invalid game, not created.");
                    }
                }
                else {
                int y = Integer.parseInt(target.replaceAll(String.valueOf(x), ""));
                //System.out.println(y);
                System.out.println(room.hit(x,y));
                }
            }
            catch (StringIndexOutOfBoundsException e) {
                System.out.println("Ending program...");
                target = "";
            }
            catch (NumberFormatException e) {
                System.out.println("Invalid input!");
            }
            boolean found = false;
            for(Ship i : room.getShips()) {
                if(!i.isDestroyed()) {
                    found = true;
                }
            }
            if(!found) {
                win = true;
                System.out.println("Congratulations! All ships are destroyed! Restart? (y/n)");
                String restart = reader.nextLine();
                if(restart.charAt(0) == 'y') {
                    room.generateRoom(2,0);
                    win = false;
                    System.out.println(room.toString());
                }
            }
        } while(target != "" && !win);
        return;
    
    }
    
}
