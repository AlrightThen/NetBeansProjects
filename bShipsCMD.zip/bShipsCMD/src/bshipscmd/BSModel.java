/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipscmd;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

/**
 *
 * @author 16031521
 */
public class BSModel {
    
    private ArrayList<Entity> entities = new ArrayList<Entity>();
    private ArrayList<Ship> ships = new ArrayList<Ship>();
    
    public boolean generateRoom(int twoLength, int oneLength) {
        Random rand = new Random();
        ArrayList<Integer> lengths = new ArrayList<>();
        lengths.add(5);
        lengths.add(4);
        lengths.add(3);
        if(twoLength > 3 || oneLength > 4 || twoLength < 0 || oneLength < 0)
            return false;
        clearRoom();
        for(int i = 0; i < twoLength; i++)
            lengths.add(2);
        for(int i = 0; i < oneLength; i++)
            lengths.add(1);
        String directions[] = {"north", "east", "south", "west"};
        String direction;
        int startX;
        int startY;
        for(Integer i : lengths) {
            int j = 0;
            do {
                direction = directions[rand.nextInt(4)];
                startX = rand.nextInt(10);
                startY = rand.nextInt(10);
                j++;
            } while(isInvalid(direction, startX, startY, i) && j < 1000);
            if(j > 1000) {
                System.out.println("Room is full, cannot create ship.");
            } else {
                addShip(i,startX, startY, direction);
            }
        }
        for(int x = 0; x < 10; x++) {
            for(int y = 0; y < 10; y++) {
                if(isFree(x,y)) {
                    Water water = new Water(x,y);
                    entities.add(water);
                }
            }
        }
        //ASSERTION STUFF HERE
        int j = 0;
        for(Entity i : entities) {
            j++;
        }
        assert validateShipCount(ships) && j == 100;
        //END ASSERTION
        return true;
    }
    
    
    private void addShip(int length, int startX, int startY, String direction) {
        //System.out.println("uh");
        Ship ship = new Ship(length, startX, startY, direction);
        ships.add(ship);
        for(int k = 0; k < ship.getLength(); k++) {
            entities.add(ship.getPart(k));
        }
        assert ships.contains(ship);
    }
    
    public Entity getEntity(int x, int y) {
        Entity theEntity = null;
        for(Entity i : entities) {
            if(i.getX() == x && i.getY() == y) {
                theEntity = i;
            }
        }
        return theEntity;
    }
    
    
    private void clearRoom() {
        entities.clear();
        ships.clear();
    }
    
    private boolean isInvalid(String direction, int startX, int startY, int length) {
        boolean invalid = false;
        int i = 0;
        do {
            int changeX = 0;
            int changeY = 0;
            switch(direction) {
                case "north":
                    changeY = -i;
                break;
                case "east":
                    changeX = i;
                break;
                case "south":
                    changeY = i;
                break;
                case "west":
                    changeX = -i;
                break;
            }
            if(!isFree(startX+changeX,startY+changeY) || startX+changeX > 9 || startX+changeX < 0 || startY+changeY > 9 || startY+changeY < 0) {
                invalid = true;
                //System.out.println("invalid");
            }
        i++;
        } while(i < length && !invalid);
        return invalid;
    }
    
    /**
     *  Method that tell us if a cell is occupied by an entity
     * @param x  row 0 {@literal <=} x {@literal <=} 9
     * @param y column 0 {@literal <=} y {@literal <=} 9
     * Determines how to
     * @return true if cell is free
     */
    private boolean isFree(int x, int y) {
        boolean free = true;
        for(Entity i : entities) {
            if(i.getX() == x && i.getY() == y) free = false;
        }
        return free;
    }
    
    /**
     * method that return string used to display the room as specified
     * @return fgbhdsf
     */
    
    public String toString(boolean cheat) {
        String str[] = {"","","","","","","","","",""};
        char[][] symbols = new char[10][10];
        for(int y = 0; y < 10; y++)
        {
            str[y] = Integer.toString(y) + " ";
            for(int x = 0; x < 10; x++)
            {
                symbols[x][y] = findSymbol(x,y,cheat);
                str[y] += symbols[x][y] + " ";
            }
        }
        String st = "  ";
        String[] alphabet = {"A","B","C","D","E","F","G","H","I","J"};
        for(int i = 0; i < 10; i++) st+= alphabet[i] + " ";
        st+="\n";
        for (String str1 : str)st += str1 + "\n";
        return st;
    }
    public ArrayList<Entity> getEntities() {
        return entities;
    }
    
    private char findSymbol(int x, int y, boolean cheat) {
        char symbol = '.';
        if(isFree(x,y)) symbol = '.';
        else
        {
            for(Entity i : entities)
            {
                if(i.getX() == x && i.getY() == y) {
                    if(i.getHit() && i.getType() == "water") symbol = 'X';
                    else if(i.getHit() && i.getType() == "ship part") symbol = 'O';
                    else if(i.getType() == "ship part" && cheat) symbol = 'S';
                }
            }
        }
        assert symbol == '.' || symbol == 'O' || symbol == 'X' || (cheat && symbol == 'S');
        return symbol;
    }
    
    /*private void getShipLengths() {
        String[] alphabet = {"A","B","C","D","E","F","G","H","I","J"};
        for(Ship i : ships) {
            System.out.println(i.getLength());
            for(int j = 0; j < i.getLength(); j++)
                System.out.println(alphabet[i.getPart(j).getX()] + "," + i.getPart(j).getY());
        }
    }*/
    
    public String hit(char xSymb, int y) {
        int x = 100;
        String message = "";
        char[] alphabet = {'A','B','C','D','E','F','G','H','I','J'};
        for(int i = 0; i < alphabet.length; i++) {
            if(alphabet[i] == xSymb) x = i;
        }
        if(x == 100)
            message = "Invalid X coordinate! X must be an upper case letter between A-J.\n";
        else if(y > 9 || y < 0)
            message = "Invalid Y coordinate! Y must be a number between 0-9\n";
        else if(!getEntity(x,y).getHit()) {
            message = hitEntity(x,y);
        }
        else {
            message = "You've already hit there!\n";
        }
        return message;
    }
    
    private String hitEntity(int x,int y) {
        boolean destruction = false;
        String message = "";
        for(Entity i : entities) {
            if(i.getX() == x && i.getY() == y) {
                i.setHit(true);
                if(i.getType() == "ship part") {
                    for(Ship j : ships) {
                        int l = j.getLength();
                        for(int k = 0; k < l; k++) {
                            ShipPart part = j.getPart(k);
                            if(part.getX() == x && part.getY() == y) {
                                part.setHit(true);
                                if(j.isDestroyed()) {
                                    j.destroy();
                                    message = "Ship of length " + l + " destroyed!";
                                } else {
                                    message = "HIT!\n";
                                }
                            }
                        }
                    }
                }
                else message = "MISS!\n";
            }
        }
        return message;
    }
    
    public void saveEntities() throws IOException {
        assert validateShipCount(ships) && validateEntityCount(entities);
        File file = new File("game.txt");
        int i = 0;
        try (FileWriter fileWriter = new FileWriter(file))
        {
            Iterator<Ship> shipIter = ships.iterator();
            while(shipIter.hasNext())
            {
                Ship it = shipIter.next();
                fileWriter.write("Length: "+it.getLength()+"\n");
                fileWriter.write("Direction: "+it.getDirection()+"\n");
                fileWriter.write("StartX: "+Integer.toString(it.getPart(0).getX())+"\n");
                fileWriter.write("StartY: "+Integer.toString(it.getPart(0).getY())+"\n");
                for(int j = 0; j < it.getLength(); j++) {
                    fileWriter.write("XPosition: "+Integer.toString(it.getPart(j).getX())+"\n");
                    fileWriter.write("YPosition: "+Integer.toString(it.getPart(j).getY())+"\n");
                    fileWriter.write("Hit: "+String.valueOf(it.getPart(j).getHit())+"\n");
                    fileWriter.write("Part: "+j+"\n");
                }
                fileWriter.write("Ship "+Integer.toString(i)+"\n");
                i++;
            }
            fileWriter.write("\n"+"\n");
            Iterator<Entity> iter = entities.iterator();
            while(iter.hasNext())
            {
                Entity it = iter.next();
                String type = it.getType();
                fileWriter.write("Type: "+type+"\n");
                fileWriter.write("XPosition: "+Integer.toString(it.getX())+"\n");
                fileWriter.write("YPosition: "+Integer.toString(it.getY())+"\n");
                fileWriter.write("Hit: "+String.valueOf(it.getHit())+"\n");
                fileWriter.write("Entity "+Integer.toString(i)+"\n");
                i++;
            }
            fileWriter.flush();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }   
    }
    
    /**
     * Method for version 1 that clears the room and creates a new list with the
     * entities read in a text file "game.txt"
     * 
     * @throws IOException gfdgd
     */
    public boolean loadEntities() throws IOException {
        boolean valid = true;
        String line = "";
        String type = "";
        int x = 0;
        int y = 0;
        int startX = 0;
        int startY = 0;
        int length = 0;
        String direction = "";
        boolean hit = false;
        boolean invalid = false;
        ArrayList<ShipPart> parts = new ArrayList<>();
        ArrayList<Ship> tempShips = new ArrayList<>();
        ArrayList<Entity> tempEntities = new ArrayList<>();
        for(int m = 0; m < 5; m++) {
            parts.add(null);
        }
        try 
        {
            //clearRoom();
            FileReader fileReader = new FileReader("game.txt");
            BufferedReader bufferedReader = new BufferedReader(fileReader);
            while((line = bufferedReader.readLine()) != null)
            {
                String[] words = line.split(" ");
                switch(words[0])
                {
                    case "Length:":
                        length = Integer.parseInt(words[1]);
                    break;
                    case "Direction:":
                        direction = words[1];
                    break;
                    case "Type:":
                        type = words[1];
                    break;
                    case "StartX:":
                        startX = Integer.parseInt(words[1]);
                    break;
                    case "StartY:":
                        startX = Integer.parseInt(words[1]);
                    break;
                    case "XPosition:":
                        x = Integer.parseInt(words[1]);
                    break;
                    case "YPosition:":
                        y = Integer.parseInt(words[1]);
                    break;
                    case "Hit:":
                        hit = Boolean.parseBoolean(words[1]);
                    break;
                    case "Part:":
                        ShipPart part = new ShipPart(x, y);
                        part.setHit(hit);
                        int index = Integer.parseInt(words[1]);
                        parts.set(index,part);
                    break;
                    case "Ship":
                        Ship ship = new Ship(length, startX, startY, direction);
                        if(ship.isDestroyed()) {
                            ship.destroy();
                        }
                        for(int j = 0; j < length; j++) {
                            ship.setPart(j, parts.get(j));
                            //System.out.println(parts.get(j).getX() + " " + parts.get(j).getY());
                            if(parts.get(j).getX() > 9 || parts.get(j).getX() < 0 || parts.get(j).getY() > 9 || parts.get(j).getY() < 0) {
                                invalid = true;
                            } else {
                                invalid = false;
                            }
                        }
                        if(!invalid) {
                            tempShips.add(ship);
                            for(int k = 0; k < ship.getLength(); k++) {
                                tempEntities.add(ship.getPart(k));
                            }
                        }
                    break;
                    case "Entity":
                        switch(type)
                        {
                            case "water":
                                Water water = new Water(x,y);
                                water.setHit(hit);
                                tempEntities.add(water);
                            break;
                        }
                    break;
                }
            }
            bufferedReader.close();
            
            if(validateShipCount(tempShips) && validateEntityCount(tempEntities)) {
                clearRoom();
                ships = tempShips;
                entities = tempEntities;
            } else {
                valid = false;
            }
        }
        catch(IOException e) {
            e.printStackTrace();
        }
        //ASSERTION STUFF HERE
        if(valid)
            assert validateShipCount(ships) && validateEntityCount(entities);
        else
            assert !validateShipCount(ships) || validateEntityCount(entities);
        //END ASSERTION
        return valid;
    }
    
    private boolean validateShipCount(ArrayList<Ship> ships) {
        boolean valid = true;
        int counts[] = {0,0,0,0,0};
        for(Ship i : ships) {
            int l = i.getLength();
            if(l > 5) {
                valid = false;
                System.out.println("Load failed, all ships must be of length between 1-5.");
            } else {
                counts[l-1]++;
            }
        }
        if(counts[4] != 1 || counts[3] != 1 || counts[2] != 1 || counts[1] < 0 || counts[1] > 3 || counts[0] < 0 || counts[0] > 4) {
            valid = false;
            System.out.println("Load failed, there must be 1 ship of lengths 5, 4, 3 between 0-3 ships of length 2 and between 0-4 ships of length 1.");
        }
        return valid;
    }
    
    private boolean validateEntityCount(ArrayList<Entity> entities) {
        int j = 0;
        for(Entity i : entities)
            j++;
        return j == 100;
    }
    
    public ArrayList<Ship> getShips() {
        return ships;
    }
    
}
