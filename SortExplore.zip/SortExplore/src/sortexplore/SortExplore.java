/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sortexplore;



import java.util.*; // this package provides random number generating facilities

/** This class contains some code
  *
  * @author David Lightfoot 2010-11-15, updated by Sharon Curtis 2011-06-09,
  *         further updated by (your student name and number here)
  */
public class SortExplore {

    public static void main(String[] args) {

        int numElements = 200000; // edit this to change number of elements in array

        // first to set up a sequence with random numbers
        Random generator = new Random();
        Sequence s = new Sequence(numElements);
        for (int i = 0; i < numElements; i++) {
            s.insertAt(i, generator.nextInt());
        }

        Sequence oldS = new Sequence(numElements); // will hold original sequence
        // now to make oldS a copy of s
        for (int i = 0; i < numElements; i++) {
            oldS.a[i] = s.a[i];
        }



        System.out.println("Before sorting by Insertion Sort");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        // System.out.println(s);
        Sequence.clearNumSteps();
        System.out.println("STARTING Insertion Sort");
        s.insertionSort();
        System.out.println("Insertion Sort done");

        System.out.println("After sorting by Insertion Sort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
        //  System.out.println(s);
        Sequence.clearNumSteps();
        System.out.println("Insertion sorting again");
        System.out.println("STARTING Insertion Sort");
        s.insertionSort();
        System.out.println("Insertion Sort done");

        System.out.println("After sorting by Insertion Sort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());

        Sequence.clearNumSteps();
        System.out.println("Restoring unsorted sequence ");
        for (int i = 0; i < numElements; i++) { // restoring original s
            s.a[i] = oldS.a[i];
        }
        System.out.println("STARTING QuickSort");
        s.quickSort();
        System.out.println("QuickSort done");

        System.out.println("After sorting by QuickSort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
        Sequence.clearNumSteps();
        System.out.println("Quick sorting again");
        System.out.println("STARTING QuickSort");
        s.quickSort();
        System.out.println("After sorting by QuickSort ");
        System.out.println("sequence is ascending?:  " + s.isAscending());
        System.out.println("Number of steps is: " + Sequence.getNumSteps());
    }
}

/* run:
Before sorting by Insertion Sort
sequence is ascending?:  false
STARTING Insertion Sort
Insertion Sort done
After sorting by Insertion Sort 
sequence is ascending?:  true
Number of steps is: 9969064455
Insertion sorting again
STARTING Insertion Sort
Insertion Sort done
After sorting by Insertion Sort 
sequence is ascending?:  true
Number of steps is: 399998
Restoring unsorted sequence 
STARTING QuickSort
QuickSort done
After sorting by QuickSort 
sequence is ascending?:  true
Number of steps is: 4719762
Quick sorting again
STARTING QuickSort
After sorting by QuickSort 
sequence is ascending?:  true
Number of steps is: 3400022
BUILD SUCCESSFUL (total time: 6 seconds)

The first time round the quick sort is significantly more efficient than the insertion sort,
however the second time round the insertion sort is more efficient than the quick sort.
This is because the second time around the insertion sort while loop already has all the
conditions of (j != 0 && a[j - 1] > x) being true, therefore will not iterate after a second sort,
however the quick sort will have to repeat the steps, because the low and high values will
be lower and higher respectively than the pivot value, therefore will have to do a similar number of
iterations to the first time*/

