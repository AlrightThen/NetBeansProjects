/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

//import java.util.ArrayList;
//import java.util.List;
/**
 *
 * @author 16031521
 */
public class main {

    /**
     * @param args the command line arguments
     */
    static ModuleBinaryTree modTree = new ModuleBinaryTree();
    static Module dataStructures = new Module("U08223", "Data Structures");
    static Module understandProgramming = new Module("U08008", "Understanding Programming");
    static Module analysis = new Module("U08625", "Algebra and Analysis");
    static Module requirements = new Module("U08048", "Requirements Engineering");
    static Module tester = new Module("U08001", "something");

    public static void main(String[] args) {
        modTree.add(dataStructures);
        modTree.add(understandProgramming);
        modTree.add(analysis);
        modTree.add(requirements);
        modTree.add(tester);
        modTree.getModule("U08048");
        modTree.getModule("U08625");
        modTree.getModule("U08223");
        modTree.getModule("U08008");
        modTree.getModule("U08001");
    }
}
