/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

import static java.lang.Integer.max;
import java.util.ArrayList;
import java.util.Collection;

/**
 *
 * @author dvnfkasdkbj
 */
public class ModuleBinaryTree implements IModuleBinaryTree {

    Node head;
    int size = 0;
    int rightDepth = 0;
    int leftDepth = 0;
    int nodesVisited = 0;
    Collection<Module> modules = null;

    public ModuleBinaryTree() {

    }

    class Node {

        private Module module;
        private Node right;
        private Node left;

        Node(Module module) {
            this.module = module;
        }
        Module getModule() {
            return module;
        }
    }

    @Override
    public void add(Module module) {
        nodesVisited = 0;
        head = insert(head, module);
        System.out.println("size: " + size + " depth: " + checkDepth(head));
    }

    public Node insert(Node head, Module module) {
        Node returnNode = head;
        nodesVisited++;
        if (head == null || head.module.getKey() == module.getKey()) {
            size++;
            Node newNode = new Node(module);
            head = newNode;
            returnNode = head;
            System.out.println("Module " + head.module.getModuleID() + " has been inserted, nodes visited: " + nodesVisited);
        } else if (module.getKey() > head.module.getKey()) {
            head.right = insert(head.right, module);
        } else if (module.getKey() < head.module.getKey()) {
            head.left = insert(head.left, module);
        }
        return returnNode;
    }

    @Override
    public void clear() {
        head = null;
    }

    @Override
    public Module getModule(String moduleID) {
        nodesVisited = 0;
        Module getModule = recursiveGetModule(moduleID, head);
        return getModule;
    }

    public Module recursiveGetModule(String moduleID, Node head) {
        nodesVisited++;
        Module getModule = null;
        int key = Integer.parseInt(moduleID.substring(2));
        if (head == null || head.module == null) {
            System.out.println("Module " + moduleID + " not found.");
        } else if (key > head.module.getKey()) {
            getModule = recursiveGetModule(moduleID, head.right);
        } else if (head.module.getKey() > key) {
            getModule = recursiveGetModule(moduleID, head.left);
        } else {
            getModule = head.module;
            System.out.println("Module " + getModule.getModuleID() + " has been found, nodes visited: " + nodesVisited);
        }
        return getModule;
    }

    @Override
    public Collection<Module> getModules() {
        modules = new ArrayList<Module>();
        inOrderTraversal(head);
        return modules;
    }

    public void inOrderTraversal(Node head) {
        if (head != null) {
            inOrderTraversal(head.left);
            modules.add(head.module);
            System.out.println(head.module.getKey());
            inOrderTraversal(head.right);
        }
    }

    @Override
    public boolean isEmpty() {
        boolean empty = true;
        if (head != null) {
            empty = false;
        }
        return empty;
    }

    @Override
    public Module remove(String moduleID) {
        Module removeModule = null;
        Node removeNode = null;
        int key = Integer.parseInt(moduleID.substring(2));
        boolean leftNode = true;
        boolean done = false;
        int descendants = 0;
        if (isEmpty()) {
            System.out.println("Tree is empty.");
        } else {
            Node parentNode = head;
            Node nodeFind = head;
            while (!done && nodeFind.module.getKey() != key ) {
                parentNode = nodeFind;
                if (key < nodeFind.module.getKey()) {
                    leftNode = true;
                    nodeFind = nodeFind.left;
                } else {
                    leftNode = false;
                    nodeFind = nodeFind.right;
                }
                if (nodeFind == null) {
                    done = true;
                }
            }
            if(!done) {
            if (nodeFind.left == null && nodeFind.right == null) {
                descendants = 0;
                if (nodeFind == head) {
                    head = null;
                } else if (leftNode) {
                    parentNode.left = null;
                } else {
                    parentNode.right = null;
                }
            } else if (nodeFind.left == null) {
                descendants = 1;
                if (nodeFind == head) {
                    head = nodeFind.right;
                } else if (leftNode) {
                    parentNode.left = nodeFind.right;
                } else {
                    parentNode.right = nodeFind.right;
                }
            } else if (nodeFind.right == null) {
                descendants = 1;
                if (nodeFind == head) {
                    head = nodeFind.left;
                } else if (leftNode) {
                    parentNode.left = nodeFind.left;
                } else {
                    parentNode.right = nodeFind.left;
                }
            } else {
                descendants = 2;
                Node replacement = findMinimum(nodeFind);
                if (nodeFind == head) {
                    head = replacement;
                } else if (leftNode) {
                    parentNode.left = replacement;
                } else {
                    parentNode.right = replacement;
                }
                replacement.left = nodeFind.left;
            }
            size--;
            removeModule = nodeFind.module;
        System.out.println("Node removed: " + removeModule.getModuleID() + " size: " + size + " depth: " + checkDepth(this.head));
        switch(descendants) {
            case 0:
                System.out.println("Node was a leaf of the tree.");
            break;
            case 1:
                System.out.println("Node had one descendant.");
            break;
            case 2:
                System.out.println("Node had two descendants.");
        }
        }
        }
        if(done) System.out.println("Node: "+moduleID+" not found.");
        return removeModule;
    }

    public Node findMinimum(Node head) {
        Node parentNode = head;
        Node minNode = head;
        Node findNode = head.right;

        while (findNode != null) {
            parentNode = minNode;
            minNode = findNode;
            findNode = findNode.left;
        }
        if (minNode != head.right) {
            parentNode.left = minNode.right;
            minNode.right = head.right;
        }
        System.out.println("Minimum: " + minNode.module.getModuleID());
        return minNode;
    }

    public int checkDepth(Node head) {
        int depth = 0;
        if (head == null) {
            depth = 0;
        } else {
            int leftDepth = checkDepth(head.left);
            int rightDepth = checkDepth(head.right);

            depth = max(leftDepth, rightDepth) + 1;
        }
        return depth;
    }

    @Override
    public int size() {
        return size;
    }

}
