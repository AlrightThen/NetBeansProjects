/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

/**
 *
 * @author 16031521
 */
public class Module implements iModule {

    private String moduleID;
    private String moduleName;
    private int key;
    
    public Module (String moduleID, String moduleName) {
        this.moduleID = moduleID;
        this.moduleName = moduleName;
        key = Integer.parseInt(moduleID.substring(2));
    }
    
    /**
     * Retrieves the Module's ID
     * @pre true
     * @return the Module's ID
     */
    @Override
    public String getModuleID() {
        return moduleID;
    }
    
    public void setModuleID(String moduleID) {
        this.moduleID = moduleID;
        key = Integer.parseInt(moduleID.substring(2));
    }
    
    /**
     * Retrieves the name of the Module
     * @pre true
     * @return the name of the Module
     */
    @Override
    public String getModuleName() {
        return moduleName;
    }
    
    public int getKey() {
        return key;
    }
}
