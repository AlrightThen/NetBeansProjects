/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tester;

/** A class for testing a binary search method.
  *
  * @author 16031521
  */
public class Tester {


/** Carries out tests on a binary search method in the AscendingSequences class.
  *
  * @param args   not used
  */
    public static void main(String[] args) {

        // First need to set up a sequence with some data:
        AscendingSequence as = new AscendingSequence(25);
        System.out.println("Adding some elements to the sequence:");
        int[] somexs = {7, 4, 6, 3, 20, -12, -5, 9}; //added an extra element to test for an even number of elements as well as an odd number
        as.insertLots(somexs);
        System.out.println(as);

        // Now to a test with this particular sequence:
        System.out.println("Can the binary search find the middle element?");  //Initial value tests below:
        System.out.println("Result of search for 4: " + as.search(4));
        System.out.println("Can the binary search find the first element?");
        System.out.println("Result of search for -12: " + as.search(-12)); //Expected to return true, returned false
        System.out.println("Can the binary search find the second element?");
        System.out.println("Result of search for -5: " + as.search(-5)); //Expected to return true, did return true
        System.out.println("Can the binary search find the third element?");
        System.out.println("Result of search for 3: " + as.search(3)); //Expected to return true, returned false
        System.out.println("Can the binary search find the fith element?");
        System.out.println("Result of search for 6: " + as.search(6)); //Expected to return true, returned false
        System.out.println("Can the binary search find the sixth element?");
        System.out.println("Result of search for 7: " + as.search(7)); //Expected to return true, did return true
        System.out.println("Can the binary search find the last element?");
        System.out.println("Result of search for 20: " + as.search(20)); //Expected to return true, returned false
        System.out.println("Can the binary search find an element that doesn't exist?");
        System.out.println("Result of search for 1: " + as.search(1)); //Expected to return false, did return false
        System.out.println("Can the binary search find new element?");
        System.out.println("Result of search for 9: " + as.search(9)); //Expected to return true, returned false

        // Now do some more tests of your own. Include at least six examples.
		// Remember that you can clear the sequence and insertLots to make a new sequence to test
		// You can search also for elements that have been deleted etc

    }
}