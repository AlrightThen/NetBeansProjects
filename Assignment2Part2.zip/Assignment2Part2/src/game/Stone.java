/**
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import game.Room;

/**
 * Subclass of Entity for the stones.
 * @author Alec
 */
public class Stone extends Entity
{
    /**
     * 
     * @param x determines the x coordinate of the stone on construction
     * @param y determines the y coordinate of the stone on construction
     */
    public Stone (int x, int y)
    {
        super(x,y);
        this.setType("stone");
        this.setSymbol('S');
    }
    /**
     * The stone does not move.
     * @param r the room the stone is in.
     */
    @Override
    public void move (Room r)
    {
        
    }
}
