

/*
 * Abstract Class Entity
 * 
 */

package game;


/**
 * The main superclass of the entities within the game.
 * @author Arantza
 */
public abstract class Entity
{
    private char symbol; // symbol that represents the entity
    private String type; // every entity is of a type
    private int x; // x coordinate in the room
    private int y; // y coordinate in the room
    private int health; // the health of the entity
    /**
     * 
     * @param x determines the x coordinate of the entity on construction
     * @param y determines the y coordinate of the entity on construction
     */
    public Entity (int x, int y)
    {
        type = "entity";
        this.x=x;
        this.y =y;
    }
    /**
     * accessor "getter" method for char symbol.
     * @return which symbol the entity has
     */
    public char getSymbol() 
    {
        return symbol;
    }
    /**
     * mutator "setter" method for char symbol.
     * @param c the new char to set the entity's symbol as
     */
    public void setSymbol(char c) 
    {
        symbol = c;
    }
/**
 * accessor method for int x.
 * @return what x coordinate the entity has.
 */
    public int getX() 
    {
        return x;
    }
 /**
 * accessor method for int y.
 * @return what y coordinate the entity has.
 */
    public int getY() 
    {
        return y;
    }
    /**
     * mutator "setter" method for int x.
     * @param newx the new int to set the entity's x coordinate as
     */
    public void setX (int newx) 
    {
        this.x=newx;
    }
    /**
     * mutator "setter" method for int y.
     * @param newy the new int to set the entity's y coordinate as
     */
    public void setY (int newy)
    {
        this.y=newy;
    }
 /**
 * accessor method for string type.
 * @return what type the entity is.
 */
    public String getType()
    {
        return type;
    }
 /**
 * mutator method for string type.
 * @param type string to set the entity's type to.
 */
    public void setType(String type)
    {
        this.type = type;
    }
    /**
    * accessor method for int health.
    * @return how much health the entity has.
    */
    public int getHealth()
    {
        return health;
    }
    /**
    * mutator method for int health.
    * @param health int to set the entity's health to.
    */
    public void setHealth(int health)
    {
        this.health = health;
    }
/**
 * abstract method for moving the entity.
 * @param r which room to move in.
 */
    public abstract void move(Room r);

}
