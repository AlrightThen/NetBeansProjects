package game;
import game.Room;
import game.Entity;
import java.util.ArrayList;
import java.util.Observable;
import java.io.FileNotFoundException;
import java.io.IOException;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author p0073862
 */
public class KModel extends Observable {

    private static final int WIDTH = 600;
   
    Room room = new Room();
  
    public KModel () throws FileNotFoundException
    {
    }

    public ArrayList<Entity> getShapes()
    {
        return room.getEntities();
    }

   

   

    public void reset()
    {
        room.resetRoom();
        sendUpdate();
    }

    private void sendUpdate()
    {
        setChanged();
        notifyObservers();
    }

    void move()
    {
        room.move();
        sendUpdate();
    }

    void load() throws IOException
    {
        room.loadEntities();
        sendUpdate();
    }

    void save() throws IOException
    {
        room.saveEntities();
        sendUpdate();
    }
}
