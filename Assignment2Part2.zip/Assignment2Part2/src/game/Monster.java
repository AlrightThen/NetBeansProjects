/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import game.Room;
import java.util.Random;

/**
 * Subclass of Entity for the monsters.
 * Contains new attribute int strength.
 * @author Alec
 */
public class Monster extends Entity
{
    private int strength;
    /**
     * 
     * @param x determines the x coordinate of the monster on construction
     * @param y determines the y coordinate of the monster on construction
     * @param strength int to set the strength of the monster to.
     * @param health value to set the health of the monster to.
     */
    public Monster (int x, int y, int strength, int health)
    {
        super(x,y);
        this.setType("monster");
        this.setSymbol('*');
        this.strength = strength;
        this.setHealth(health);
    }
    /**
     * Accessor method of int strength.
     * @return the strength of the monster.
     */
    public int getStrength()
    {
        return strength;
    }
    /**
     * Mutator method of int strength.
     * @param strength int to set the strength of the monster to.
     */
    public void setName(int strength)
    {
        this.strength = strength;
    }
    /**
     * Method for moving the monster.
     * The monster moves to a free space whose distance from the original space is equal to or less than the strength (prioritising the highest value) in a random direction. The monster loses health equal to its strength regardless of the distance.
     * @param r which room the monster will move in.
     */
    @Override
    public void move (Room r)
    {
        Random rn = new Random();
        boolean moved = false;
        int k = 0;
        while(k < getStrength() && !moved)
        {
            int mo[][] = {{-getStrength()+k,0},{0,getStrength()-k},{0,-getStrength()+k},{getStrength()-k,getStrength()-k},{getStrength()-k,-getStrength()+k},{-getStrength()+k,getStrength()-k},{-getStrength()+k,getStrength()-k},{getStrength()-k,0}};
            int j = 0;
            while(j < mo.length && !moved)
            {
                int i = rn.nextInt(8);
                if(r.isFree(getX()+mo[i][0],getY()+mo[i][1]) && getX()+mo[i][0] < 10 && getY()+mo[i][1] < 10)
                {
                    setX(getX()+mo[i][0]);
                    setY(getY()+mo[i][1]);
                    moved = true;
                }
                mo[i][0] = 2;
                j++;
            }
            k++;
        }
        setHealth(getHealth()-getStrength());
    }
}
