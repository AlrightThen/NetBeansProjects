/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package barcharts;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.event.ActionEvent;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.CheckBox;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.FileChooser;
import javafx.stage.FileChooser.ExtensionFilter;
import javafx.stage.Stage;

/**
 *
 * @author 16031521
 */
public class BarCharts extends Application {

    //Initializing values
    final TextField titleText = new TextField();
    final TextField xAxisText = new TextField();
    final TextField yAxisText = new TextField();
    final TextField[] valueField = new TextField[10];
    final TextField[] itemNameField = new TextField[10];
    final boolean[] fieldDisabled = new boolean[10];
    CheckBox[] checkBox = new CheckBox[10];
    final Label errorLabel = new Label("");
    GridPane grid = new GridPane();
    GridPane grid2 = new GridPane();
    FileChooser fileChooser = new FileChooser();
    File selectedFile;

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Bar Chart Generator");
        Label label1 = new Label();
        //Creating a GridPane container
        Scene scene = new Scene(grid, 700, 700);
        Scene scene2 = new Scene(grid2, 700, 700);
        grid.setPadding(new Insets(10, 10, 10, 10));
        grid.setVgap(5);
        grid.setHgap(10);
        //Title
        final Label title = new Label("Title");
        grid.add(title, 0, 0);
        //X axis
        final Label XAxis = new Label("X-Axis");
        grid.add(XAxis, 0, 1);
        //Y axis
        final Label YAxis = new Label("Y-Axis");
        grid.add(YAxis, 0, 2);
        //Text Field Title
        titleText.setPromptText("Title");
        grid.add(titleText, 1, 0);
        //Text Field X Axis
        xAxisText.setPromptText("Enter title:");
        grid.add(xAxisText, 1, 1);
        //Text Field Y Axis
        yAxisText.setPromptText("Enter title:");
        grid.add(yAxisText, 1, 2);
//////////////////////BEGIN ITEMS//////////////////////////////
        //Item Name Label
        final Label ItemNameLabel = new Label("Item Name");
        grid.add(ItemNameLabel, 2, 0);
        //Item Name Fields
        for (int i = 0; i < 10; i++) {
            itemNameField[i] = new TextField();
            itemNameField[i].setPrefColumnCount(15);
            itemNameField[i].setPromptText("Item name " + (i + 1));
            grid.add(itemNameField[i], 2, i + 1);
        }
        //Value Label
        final Label ValueLabel = new Label("Value");
        grid.add(ValueLabel, 3, 0);
        //Value Fields
        for (int i = 0; i < 10; i++) {
            valueField[i] = new TextField();
            valueField[i].setPrefColumnCount(15);
            valueField[i].setPromptText("e.g. 50");
            grid.add(valueField[i], 3, i + 1);
        }
        //Check Box Label
        final Label CheckBoxLabel = new Label("Enabled");
        grid.add(CheckBoxLabel, 4, 0);
        //Check Boxes
        for (int i = 0; i < 10; i++) {
            checkBox[i] = new CheckBox();
            checkBox[i].setSelected(true);
            final int j = i;
            checkBox[i].setOnAction((ActionEvent ae) -> {
                CheckBox source = (CheckBox) ae.getSource();
                if (source.isSelected()) {
                    itemNameField[j].setDisable(false);
                    valueField[j].setDisable(false);
                    fieldDisabled[j] = false;
                } else {
                    itemNameField[j].setDisable(true);
                    valueField[j].setDisable(true);
                    fieldDisabled[j] = true;
                }
            }
            );
            grid.add(checkBox[i], 4, i + 1);
        }
        /**/
        //Generate Bar Chart Button
        Button barChartButton = new Button("Generate Bar Chart");
        //barChartButton.setLabel("Generate Bar Chart");
        barChartButton.setOnAction((ActionEvent ae) -> {
            barGraph(primaryStage, scene2);
        });
        grid.add(barChartButton, 1, 3, 2, 1);
        //Generate CSV Bar Chart Button
        Button CSVButton = new Button("Generate From CSV");
        //barChartButton.setLabel("Generate Bar Chart");
        CSVButton.setOnAction((ActionEvent ae) -> {
            fileChooser.setTitle("Open Resource File");
            fileChooser.getExtensionFilters().addAll(
                    new ExtensionFilter("CSV Files", "*.csv"),
                    new ExtensionFilter("All Files", "*.*"));
            selectedFile = fileChooser.showOpenDialog(primaryStage);
            if (selectedFile != null) {
                csvBarGraph(primaryStage, scene2);
            }

        });
        grid.add(CSVButton, 1, 4, 2, 1);
        //Error Label
        grid.add(errorLabel, 0, 5, 2, 2);
        //Scene setting
        primaryStage.setScene(scene);
        primaryStage.setResizable(false);
        primaryStage.show();
        System.out.println(yAxisText.getText());
    }

    public void barGraph(Stage stage, Scene scene) {
        stage.setTitle(titleText.getText());
        final CategoryAxis xAxis = new CategoryAxis();
        final NumberAxis yAxis = new NumberAxis();
        final BarChart<String, Number> bc = new BarChart<>(xAxis, yAxis);
        bc.setTitle(titleText.getText());
        xAxis.setLabel(xAxisText.getText());
        yAxis.setLabel(yAxisText.getText());

        XYChart.Series series1 = new XYChart.Series();
        boolean error = false;
        for (int i = 0; i < 10; i++) {

            if (!fieldDisabled[i]) {
                if (!itemNameField[i].getText().isEmpty() && !titleText.getText().isEmpty() && !xAxisText.getText().isEmpty() && !yAxisText.getText().isEmpty()) {
                    String value = valueField[i].getText();
                    try {
                        double doubleValue = Double.parseDouble(value);
                    } catch (NumberFormatException nfe) {
                        errorLabel.setText("Error:\n -Value(s) in value fields are not numbers");
                        error = true;
                    }
                    if (!error) {
                        series1.getData().add(new XYChart.Data(itemNameField[i].getText(), Double.parseDouble(value)));
                    }
                } else {
                    errorLabel.setText("Error:\n -Some fields have no text.");
                    error = true;
                }
            }
        }
        if (!error) {
            scene = new Scene(bc, 800, 600);
            bc.getData().addAll(series1);
            stage.setScene(scene);
            stage.show();
        }
    }

    public void csvBarGraph(Stage stage, Scene scene) {
        try {
            String line;
            BufferedReader buffer = new BufferedReader(new FileReader(selectedFile));
            line = buffer.readLine();
            String[] item = line.split(",");
            final CategoryAxis xAxis = new CategoryAxis();
            final NumberAxis yAxis = new NumberAxis();
            final BarChart<String, Number> bc = new BarChart<>(xAxis, yAxis);
            bc.setTitle(item[0]);
            stage.setTitle(item[0]);
            yAxis.setLabel(item[1]);
            xAxis.setLabel(item[2]);
            XYChart.Series series1 = new XYChart.Series();
            while ((line = buffer.readLine()) != null) {
                item = line.split(",");
                series1.getData().add(new XYChart.Data(item[0], Double.parseDouble(item[1])));
                System.out.println(item[0] + " " + item[1]);
            }
            scene = new Scene(bc, 800, 600);
            bc.getData().addAll(series1);
            stage.setScene(scene);
            stage.show();

        } catch (IOException ioe) {
            errorLabel.setText("Error:\n -File not found or in wrong format, make sure you type the whole\n file name including .csv at the end.");
        } catch (NumberFormatException nfe) {
            errorLabel.setText("Error:\n -Value(s) in value field(s) are not numbers,\n make sure all are decimal numbers");
        } catch (ArrayIndexOutOfBoundsException aioobe) {
            errorLabel.setText("Error:\n Wrong file format, make sure it is a csv file.");
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
}
