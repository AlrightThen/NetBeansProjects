package game;

import java.util.Random;

/**
 * Subclass of Entity for the non-flying dragon.
 * @author Alec
 */
public class Dragon extends Entity
{
    /**
     * 
     * @param x determines the x coordinate of the dragon on construction
     * @param y determines the y coordinate of the dragon on construction
     * @param health value to set the health of the dragon to.
     */
    public Dragon (int x, int y, int health)
    {
        super(x,y);
        this.setType("Non-flyingDragon");
        this.setSymbol('#');
        this.setHealth(health);
    }
    /**
     * Method for moving the dragon.
     * The dragon moves to a random free adjacent space and loses randomly 0-5 health.
     * @param r which room the dragon will move in.
     */
    @Override
    public void move (Room r)
    {
        Random rn = new Random();
        boolean moved = false;
        int mo[][] = {{-1,0},{0,1},{0,-1},{1,1},{1,-1},{-1,1},{-1,1},{1,0}};
        int j = 0;
        while(j < mo.length && !moved)
        {
            int i = rn.nextInt(8);
            if(r.isFree(getX()+mo[i][0],getY()+mo[i][1]) && getX()+mo[i][0] < 10 && getY()+mo[i][1] < 10)
            {
                setX(getX()+mo[i][0]);
                setY(getY()+mo[i][1]);
                moved = true;
            }
            mo[i][0] = 2;
            j++;
        }
        setHealth(getHealth()-rn.nextInt(5));
    }
}

