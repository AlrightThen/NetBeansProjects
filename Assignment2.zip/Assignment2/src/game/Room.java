package game;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.io.IOException;

/**
 * Class that stores the positions of all the entities.
 * Methods to add entities, display the room, display information are not implemented.
 * Import "FileNotFoundException" was replaced with "IOException" due to ease of use.
 * @author Arantza
 */
public class Room
{
 // List with all the entities
    private ArrayList<Entity> entities = new ArrayList<Entity>();
    private final String[] HumanNames = {"Harold","David","Clare"};
    private final String[] Types = {"Hole","Hole","Stone","Stone","Monster","Monster","Monster","Dragon","DragonFlying"};

 /**
  * Set up a new room with entities in random places
  * first the room, must be clear of entities
  * Next the
  */
    public void resetRoom()
    {
        clearRoom();
        for (String Type : Types) addEntity(Type,0); 
        addEntity("Human",0);
        addEntity("Human",1);
        addEntity("Human",2);
    }
  /**
   * Method to add the entities of a specific type to the entities arraylist
   * @param type string which determines which entity extension to add to the arraylist
   * @param name integer which determines which name to use for the humans by calling from an array of strings with the human name. 
   */
    
    public void addEntity(String type, int name)
    {
       Random rand = new Random();
       int x = rand.nextInt(10);
       int y = rand.nextInt(10);
       while(!isFree(x,y))
       {
           x = rand.nextInt(10);
           y = rand.nextInt(10);
       }
       int health = rand.nextInt(100)+1;
       switch(type)
       {
            case "Hole":
                int depth = rand.nextInt(20);
                Hole hole = new Hole(x,y,depth);
                entities.add(hole);
            break;
            case "Stone":
                Stone stone = new Stone(x,y);
                entities.add(stone);
            break;
            case "Human":
                Human human = new Human(x,y,HumanNames[name],health);
                entities.add(human);
            break;
            case "Monster":
                int strength = rand.nextInt(5);
                Monster monster = new Monster(x,y,strength,health);
                entities.add(monster);
            break;
            case "Dragon":
                Dragon dragon = new Dragon(x,y,health);
                entities.add(dragon);
            break;
            case "DragonFlying":
                DragonFlying dragonFlying = new DragonFlying(x,y,health);
                entities.add(dragonFlying);
            break;
       }
    }
   
    public ArrayList<Entity> getEntities()
    {
        return entities;
    }
    
    

    /**
     * Empty the list of entities
     */
    public void clearRoom()
    {
        entities.clear();
    } 


    /**
     *  Method that tell us if a cell is occupied by an entity
     * @param x  row 0 {@literal <=} x {@literal <=} 9
     * @param y column 0 {@literal <=} y {@literal <=} 9
     * Determines how to
     * @return true if cell is free
     */
    public boolean isFree(int x, int y)
    {
        boolean free = true;
        for(Entity i : entities)
        {
            if(i.getX() == x && i.getY() == y) free = false;
        }
        return free;
    }

    /**
     *  Method that returns the position in the arrayList occupied by an entity 
     * given its coordinates
     * @param x  row 0 <= x <= 9
     * @param y column 0 <= y <= 9
     * @return position in the list or -1 if the cell is free
     */
    private int getPosition (int x, int y)
    {
        return -1;
    }

    /**
     * Display all the properties of an entity that occupies a particular cell
     * PRE: Cell must not be empty
     * @param x row 0{@literal <=} x {@literal <=}9
     * @param y column 0{@literal <=}y{@literal <=}9
     * @return String with the properties of the entity or
	 *  	
     */
    public String displayEntity (int x, int y)
    {
        return("");
    }
    
    
    /**
     * method that moves all the entities that are animated on the room
     */
    public void move() 
    {
        Iterator<Entity> iter = entities.iterator();
        while(iter.hasNext())
        {
            Entity it = iter.next();
            it.move(this);
            if(it.getType() != "hole" && it.getType() != "stone" && it.getHealth() <= 0) iter.remove();
        }
    }
    /**
     * method that return string used to display the room as specified
     * @return fgbhdsf
     */
    
    @Override
    public String toString()
    {
        String str[] = {"","","","","","","","","",""};
        char[][] symbols = new char[10][10];
        for(int y = 0; y < 10; y++)
        {
            str[y] = Integer.toString(y) + " ";
            for(int x = 0; x < 10; x++)
            {
                symbols[y][x] = findSymbol(y,x);
                str[y] += symbols[y][x] + " ";
            }
        }
        String st = "  ";
        for(int i = 0; i < 10; i++) st+= Integer.toString(i) + " ";
        st+="\n";
        for (String str1 : str)st += str1 + "\n";
        return st;
    }
    /**
     * Method that determines what position has what symbol
     * @param x  row 0 {@literal <=} x {@literal <=} 9
     * @param y column 0 {@literal <=} y {@literal <=} 9
     * @return which symbol is in the room at positions y and x.
     */
    
    public char findSymbol(int y, int x)
    {
        char symbol = '.';
        if(isFree(x,y)) symbol = '.';
        else
        {
            for(Entity i : entities)
            {
                if(i.getX() == x && i.getY() == y) symbol = i.getSymbol();
            }
        }
        return symbol;
    }
    
    public void findEntity(int x, int y)
    {
        if(isFree(x,y)) System.out.println("No entity found.");
        else
        {
            for(Entity i : entities)
            {
                if(i.getX() == x && i.getY() == y)
                {
                    System.out.println("X Position: "+i.getX());
                    System.out.println("Y Position: "+i.getY());
                    System.out.println("Type: " + i.getType());
                    switch(i.getType())
                    {
                        case "hole":
                            Hole j = (Hole) i;
                            System.out.println("Depth: " + j.getDepth());
                        break;
                        case "human":
                            Human k = (Human) i;
                            System.out.println("Health: " + k.getHealth());
                            System.out.println("Name: " + k.getName());
                        break;
                        case "monster":
                            Monster l = (Monster) i;
                            System.out.println("Health: " + l.getHealth());
                            System.out.println("Strength: " + l.getStrength());
                        break;
                        case "Non-flyingDragon":
                            Dragon m = (Dragon) i;
                            System.out.println("Health: " + m.getHealth());
                        break;
                        case "flyingdragon":
                            DragonFlying n = (DragonFlying) i;
                            System.out.println("Health: " + n.getHealth());
                        break;
                    }
                }
            }
        }
    }
    
    
    /**
     * Method for version 1 that clears the room and creates a new list with the
     * entities read in a text file
     * 
     * @throws IOException dont do anything yet
     */
    public void loadEntities() throws IOException
    {
    }
/**
 * Version 2
 * methods that saves the entities and their positions into a text file
 * @throws IOException dont do anything yet
 */
    public void saveEntities() throws IOException
    {
    }
}

