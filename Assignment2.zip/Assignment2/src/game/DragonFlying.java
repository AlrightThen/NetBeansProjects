/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;
import java.util.Random;

/**
 * Subclass of Entity for the flying dragon.
 * @author Alec
 */
public class DragonFlying extends Entity
{
    /**
     * 
     * @param x determines the x coordinate of the dragon on construction
     * @param y determines the y coordinate of the dragon on construction
     * @param health value to set the health of the dragon to.
     */
    public DragonFlying (int x, int y, int health)
    {
        super(x,y);
        this.setType("flyingdragon");
        this.setSymbol('#');
        this.setHealth(health);
    }
    /**
     * Method for moving the dragon.
     * The dragon moves to a random free space anywhere on the map and loses no health.
     * @param r which room the dragon will move in.
     */
    @Override
    public void move (Room r)
    {
        Random rn = new Random();
        boolean moved = false;
        while(!moved)
        {
            int x = rn.nextInt(10);
            int y = rn.nextInt(10);
            if(r.isFree(x, y))
            {
                setX(x);
                setY(y);
                moved = true;
            }
        }
    }
}
