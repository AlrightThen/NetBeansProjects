package game;
 
import java.util.Scanner;
/**
 * Main template class with the menu with all the options
 * @author Arantza
 */
public class GameController 
{
    static void menu()
    {

        System.out.println("Enter an option.");
        System.out.println(" 1: Display level.");
	System.out.println(" 2: Move animated entities.");
        System.out.println ("3: Display the properties of an entity.");
        System.out.println ("4: Reset the room.");
        System.out.println ("0: Exit.");
    }
    public static void main(String[] args) throws Exception
    {
        Room mwRoom = new Room();
        System.out.println("Initialise the room here");
        Scanner kb = new Scanner(System.in);
        mwRoom.resetRoom();
        int option;
        do 
        {
            menu();
            option = kb.nextInt();
            kb.nextLine();
            switch (option) 
            {
                case 1: System.out.println("\n"+mwRoom.toString());
                break;
                case 2:
                    System.out.println("Entities moved.");
                    mwRoom.move();
                break;
                case 3:
                    System.out.println("\nEnter the position of the entity that you want to display \n X Position: ");
                    int x = kb.nextInt();
                    System.out.println("Y Position: ");
                    int y = kb.nextInt();
                    mwRoom.findEntity(x, y);
                break;
                case 4:
                    System.out.println("\nRoom reset.");
                    mwRoom.resetRoom();
                break;
                case 0: System.out.println(" Good bye");
                break;
                default: System.out.println("Sorry wrong option");
            }
        } 
    while (option != 0);
    }
 }
