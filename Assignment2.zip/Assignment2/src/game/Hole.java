/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

/**
 * Subclass of Entity for the holes.
 * Contains new attribute int depth.
 * @author Alec
 */
public class Hole extends Entity
{
    private int depth;
    /**
     * 
     * @param x determines the x coordinate of the hole on construction
     * @param y determines the y coordinate of the hole on construction
     * @param depth value to set the depth of the hole to.
     */
    public Hole (int x, int y, int depth)
    {
        super(x,y);
        this.setType("hole");
        this.setSymbol('O');
        this.depth = depth;
    }
    /**
     * Accessor method for int depth.
     * @return the depth of the hole.
     */
    public int getDepth()
    {
        return depth;
    }
    /**
     * Mutator method for int depth.
     * @param depth value to set the depth of the hole to.
     */
    public void setDepth(int depth)
    {
        this.depth = depth;
    }
    /**
     * The hole does not move.
     * @param r the room the hole is in.
     */
    @Override
    public void move (Room r)
    {
        
    }
}
