/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

//import java.util.ArrayList;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//import java.util.List;
/**
 *
 * @author 16031521
 */
public class main {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    StudentAssociativeArray studArray = new StudentAssociativeArray(5);
    Student Jenkins = new Student("JENKINS","Maths","fbvadkjjfh49");
    Student Will = new Student("WILLIAMSON","Computing","fbvadkjjfh49");
    studArray.put(Jenkins);
        System.out.println("JENKINS in array? "+studArray.containsValue(Jenkins));
        System.out.println("WILLIAMSON in array? "+studArray.containsValue(Will));
        
    /*Student Will = new Student("WILLIAMSON","Computing","fbvadkjjfh49");
    Student Poppy = new Student("JONES","Computing","fbvadkjjfh49");*/
    
    }
}