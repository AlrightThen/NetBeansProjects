package module;

//import java.util.ArrayList;
//import java.util.List;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author 16031521
 */
public class StudentAssociativeArray implements IStudentAssociativeArray {
    
    //List<Student> students = new ArrayList<Student>();
    //Student students = null;
    private Node head;
    private int loadCompenHash = 0;
    //private double activeTable;
    
    /**
     * Removes and returns a Student from the associative array, with the key
     * the supplied surname.
     * @param surname The surname (key) to remove.
     * @pre true
     * @return the removed Student object mapped to the surname, or null if
     * the surname does not exist.
     */
    @Override
    public Student remove(String surname) {
        Student output = null;
        if(!isEmpty()) {
        if(containsSurname(surname)) {
            boolean found = false;
            Node before = head;
            Node after = head.nextNode;
            output = before.student;
            //System.out.println(output.student.getSurname());
            if(before.student != null) if(before.student.getSurname() == surname) found = true;
            while (after != null && !found) {
                if(after.student.getSurname() == surname) {
                    found = true;
                }
                before = after;
                output = before.student;
                after = after.nextNode;
            }
            before.student = null; //setting student to null to mark deletion
            before.hash = 0; //setting hash to 0 to mark deletion
        return output;
        } 
        else return null;
        } else return null;
    }

    /**
     * Returns the number of Students in the associative array
     * @pre true
     * @return number of Students in the associative array. 0 if empty
     */
    @Override
    public int size() {
        int i = 0;
        int j = 0;
        if(head != null) {
        if(head.hash!=0) i = 1; j = 1;
        Node before = head;
        Node after = head.nextNode;
            while (after != null) {
                if(after.hash!=0) i++;
                j++;
                before = after;
                after = after.nextNode;
            }
        }
        return i;
    }

    /**
     * Returns a Set view of the Students contained by the associative
     * array
     * @pre true
     * @return a Set view of Student objects contained by the associative
     * array
     */

    @Override
    public Set<Student> getStudents() {
        Set<Student> output = new HashSet();
        Node before = head;
        output.add(before.student);
        Node after = head.nextNode;
        while(after != null) {
            output.add(after.student);
            before = after;
            after = before.nextNode;
        }
        return output;
    }
    
    public class Node {
        Student student;
        int hash;
        Node nextNode;    
    }
    
    /*private class StudentIter implements Iterator<Student> {

        Node current = head;

        @Override
        public boolean hasNext() {
            return (current != null);
        }

        @Override
        public Student next() {
            Student result = current.student;
            current = current.nextNode;
            return result;
        }

        @Override
        public void remove() {
            throw new UnsupportedOperationException("Not supported.");
        }

    }*/
    
    public StudentAssociativeArray () {
        
    }
    /**
     * Empties the associative array.
     * @pre true
     */
    public void clear() {
        head = null;
    }
    
    /**
     * Determines whether a Student surname exists as a key inside the associative
     * array.
     * @pre true
     * @param surname The student surname (key) to locate
     * @return true iff the surname exists as a key in the associative array
     */
    public boolean containsSurname(String surname) {
        boolean found = false;
        if(!isEmpty()) {
        Node before = head;
        Node after = head.nextNode;
        if(before.student != null) if(before.student.getSurname() == surname) found = true;
        while (after != null && !found) {
        if(after.student != null)    if(after.student.getSurname() == surname) {
                found = true;
                //System.out.println(after.student.getSurname() + " has been found");
            }
            before = after;
            after = after.nextNode;
        }
        }
        return found;
    }
        
    
    /**
     * Determines whether a Student object exists as a value inside the associative
     * array.
     * @pre true
     * @param student The Student object to locate
     * @return true iff the Student object 'student' exists as a value in the associative array
     */
    public boolean containsValue(Student student) {
        boolean found = false;
        if(!isEmpty()) {
        Node before = head;
        Node after = head.nextNode;
        Node output = null;
        if(before.student == student) found = true;
        while (after != null && !found) {
        if(after.student != null) if(after.student == student) {
                found = true;
                output = after;
            }
            before = after;
            after = after.nextNode;
        }
        }
        return found;
    }
    
    /**
     * Returns a Student object mapped to the supplied surname.
     * @pre true
     * @param surname The student surname (key) to locate
     * @return the Student object mapped to the key surname if the surname
     * exists as key in the associative array, otherwise null
     */
    public Student getStudent(String surname) {
        boolean found = false;
        Node output = null;
        if(!isEmpty()) {
        Node before = head;
        Node after = head.nextNode;
        if(before.student.getSurname() == surname)  {
            found = true;
            output = before;
        }
        while (after != null && !found) {
            if(after.student != null) if(after.student.getSurname() == surname) {
                found = true;
                output = after;
            }
            before = after;
            after = after.nextNode;
        }
        }
        return output.student;
    }
    
    /**
     * Determines if the associative array is empty or not.
     * @pre true
     * @return true iff the associative array is empty
     */
    public boolean isEmpty() {
        if(head == null) return true;
        else return false;
    }
    
    /**
     * Returns a Set view of the surnames (keys) contained by the associative
     * array
     * @pre true
     * @return a Set view of the surnames (keys) contained by the associative
     * array
     */
    public Set<String> keySet() {
        Set<String> output = new HashSet();
        Node before = head;
        output.add(Integer.toString(before.hash));
        Node after = head.nextNode;
        while(after != null) {
        output.add(Integer.toString(after.hash));
            before = after;
            after = before.nextNode;
        }
        return output;
    }
    
    public void loadFactorCheck(double active) {
        if(active/size() > 0.75) {
            loadFactorCompensation();
        }
        System.out.println(active/size());
    }
    
    public StudentAssociativeArray loadFactorCompensation() {
        loadCompenHash++;
        System.out.println("\nLoad factor exceeds 75%, ");
        Node newHead = head;
        Node before = newHead;
        Node after = newHead.nextNode;
        int i = 0;
        int k = 0;
        int oldSize = size();
        //if(head.hash != 0)
        while(i < oldSize*2) {
            if(after == null) {
                Node newNode = new Node();
                for(int j = 1; j < i; j++) k+=j*5;
                newNode.hash = hashCheck(k,1);
                before.nextNode=newNode;
                after=before.nextNode;
            }
            before = after;
            after = after.nextNode;
            i++;
        }
        head = newHead;
        System.out.println("Old size = "+oldSize+" \nNew size = "+size());
        return this;
    }
    
    /**
     * Inserts a Student into the associative array, with the key of the supplied
     * Student's surname.
     * Note: If the surname already exists as a key, then then the original entry is
     * overwritten. This method should return the previous associated value if one exists, otherwise null
     * @pre true
     */
    @Override
    public Student put(Student student) {
        Student oldValue = null;
        if (head == null || head.student == null || head.hash==surnameHash(student.getSurname())) {
        ///////////////////Insert at HEAD////////////
        if(head!=null) if(head.hash==surnameHash(student.getSurname())) oldValue = head.student;
        Node newNode = new Node();
        newNode.student = student;
        newNode.nextNode = head;
        head = newNode;
        head.hash = addHash(newNode.student);
        } else {
        ///////////////////Insert AFTER////////////////
            Node before = head;
            Node after = head.nextNode;
            if(after != null) {
                boolean found = false;
                int i = 1;
                while(after != null && !found) {
                        loadFactorCheck(i);
                        if(after.hash == surnameHash(student.getSurname()) || after.student == null) {
                        found = true;
                        }
                    before = after;
                    after = after.nextNode;
                    i++;
                }
            }
            //INSERT AFTER
            Node newNode = new Node();
            newNode.student = student;
            newNode.nextNode = before.nextNode;
            before.nextNode = newNode;
            before.nextNode.hash = addHash(newNode.student);
            ////before//////////////
            }
        return oldValue;
    }
    
    /**
     * Custom hashcode for students
     * @pre true
     * @return the generated hashcode
     */
    
    
    
    
    public int addHash(Student student) {
        int hash = surnameHash(student.getSurname());
        hash = hashCheck(hash,1);
        return hash;
    }
    /**
     * Checks the hashcode is not conflicting for students
     * Linear probes the hash by +1 if a confliction is found
     * @param hash 
     */
    public int hashCheck(int hash, int i) {
        boolean found = false;
        ///////////////////////////////////////////////////////////////
        Node before = head;
        Node after = head.nextNode;
        if(before.hash == hash) {
            found = true;
        }
            while (after != null && !found) {
                if(after.hash == hash) {
                    found = true;
                }
                before = after;
                after = after.nextNode;
            }
        ////////////////////////////////////////////////////////////////
        if(found) return hashCheck(hash+1+(i*i),i+1);
        else return hash;
    }
    
    
    public int surnameHash(String surname) {
        int hash = 1;
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        for(int i = 1; i < surname.length(); i++) {
            for(int j = 1; j < characters.length(); j++) {
                if(surname.charAt(i) == characters.charAt(j)) {
                    hash +=(((i+43)*j+(j%i))* (j+21));
                    for(int k = 1; k < i; k++) hash*=7;
                }
            }
        }
        return hash;
    }
    
    public int getHash(Student student) {
        boolean found = false;
        Node before = head;
        Node after = head.nextNode;
        Node output = null;
        if(before.student == student) {
            found = true;
            output = before;
        }
        while (after != null && !found) {
            if(after.student == student) {
                found = true;
                output = after;
            }
            before = after;
            after = after.nextNode;
        }
        if(output == null) return 0;
        else return output.hash;
    }
}
