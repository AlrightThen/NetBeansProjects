/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

//import java.util.ArrayList;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//import java.util.List;
/**
 *
 * @author 16031521
 */
public class main {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Student Jenkins = new Student("SMITH","Computing","akdhvakj");
    Student Will = new Student("THOMPSON","Maths","zkjcbbsj");
    Student Timothy = new Student("WILKINSON","Music","a93yhbn248");
    Student Poppy = new Student("JONES","PE","aksjbvj13497");
    Student Manfred = new Student("VONVON","History","oieoi393u592u945");
    Student William = new Student("BIGS","Psychology","24873ytq2h8");
    Student William1 = new Student("BIGSA","Psychology","24873ytq2h8");
    Student William2 = new Student("BIGSB","Psychology","24873ytq2h8");
    Student William4 = new Student("BIGSC","Psychology","24873ytq2h8");
    Student William3 = new Student("BIGSD","Psychology","24873ytq2h8");
    Student William5 = new Student("BIGSE","Psychology","24873ytq2h8");
    Student William6 = new Student("BIGSF","Psychology","24873ytq2h8");
    StudentAssociativeArray studArray = new StudentAssociativeArray();
        System.out.println(studArray.size());
    studArray.put(Will);
    studArray.put(William);
    studArray.put(William1);
    studArray.put(William2);
    studArray.put(William3);
    studArray.put(William4);
    studArray.put(William5);
    studArray.put(William6);
    studArray.put(Manfred);
    System.out.println("Array contains surname SMITH: "+studArray.containsSurname("SMITH"));
        System.out.println("Array contains surname JENKINS: "+studArray.containsSurname("JENKINS"));
        System.out.println("Array contains surname THOMPSON: "+studArray.containsSurname("THOMPSON"));
        System.out.println("Array contains surname VONVON: "+studArray.containsSurname("VONVON"));
        System.out.println("\nHashcode for Jenkins Smith: "+studArray.getHash(Jenkins));
        System.out.println("Hashcode for Will Thompson: "+studArray.getHash(Will));
        System.out.println("Hashcode for Manfred Vonvon: "+studArray.getHash(Manfred));;
        System.out.println("\n Get students: "+studArray.getStudents());
        System.out.println("\n Size = "+studArray.size());
        studArray.clear();
        System.out.println("\n Size = "+studArray.size());
        System.out.println("Array contains surname SMITH: "+studArray.containsSurname("SMITH"));
        System.out.println("Array contains surname JENKINS: "+studArray.containsSurname("JENKINS"));
        System.out.println("Array contains surname THOMPSON: "+studArray.containsSurname("THOMPSON"));
        System.out.println("Array contains surname VONVON: "+studArray.containsSurname("VONVON"));
        studArray.put(Jenkins);
        studArray.put(Will);
        studArray.put(Manfred);
        studArray.put(Poppy);
        studArray.put(Timothy);
        studArray.put(William);
        System.out.println("\n Size = "+studArray.size());
        System.out.println("\nArray contains surname SMITH: "+studArray.containsSurname("SMITH"));
        System.out.println("Array contains surname JENKINS: "+studArray.containsSurname("JENKINS"));
        System.out.println("Array contains surname THOMPSON: "+studArray.containsSurname("THOMPSON"));
        System.out.println("Array contains surname VONVON: "+studArray.containsSurname("VONVON"));
        System.out.println("\nRemoving student: "+studArray.remove("SMITH").getSurname());
        System.out.println("\n Size = "+studArray.size());
        System.out.println("\nArray contains surname SMITH: "+studArray.containsSurname("SMITH"));
        System.out.println("Array contains surname THOMPSON: "+studArray.containsSurname("THOMPSON"));
        System.out.println("Array contains surname VONVON: "+studArray.containsSurname("VONVON"));
        System.out.println("\nRemoving student: "+studArray.remove("THOMPSON").getSurname());
        System.out.println("\n Size = "+studArray.size());
        System.out.println("\nArray contains surname SMITH: "+studArray.containsSurname("SMITH"));
        System.out.println("Array contains surname THOMPSON: "+studArray.containsSurname("THOMPSON"));
        System.out.println("Array contains surname VONVON: "+studArray.containsSurname("VONVON"));
        
        System.out.println("\nAdding student: "+Jenkins.getSurname());
        studArray.put(Jenkins);
        System.out.println("\n Size = "+studArray.size());
        System.out.println("\nArray contains surname SMITH: "+studArray.containsSurname("SMITH"));
        System.out.println("Array contains surname THOMPSON: "+studArray.containsSurname("THOMPSON"));
        System.out.println("Array contains surname VONVON: "+studArray.containsSurname("VONVON"));
    }
}