package module;

import java.util.HashSet;
import java.util.Set;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author 16031521
 */
public class StudentAssociativeArray implements IStudentAssociativeArray {

    //List<Student> students = new ArrayList<Student>();
    //Student students = null;
    private Student[] students;
    private String[] keys;
    private int maxSize;
    private int currentSize = 0;

    public StudentAssociativeArray(int size) {
        students = new Student[size];
        keys = new String[size];
        maxSize = size;
    }

    /**
     * Empties the associative array.
     *
     * @pre true
     */
    @Override
    public void clear() {
        for (int i = 0; i < maxSize; i++) {
            keys[i] = null;
            students[i] = null;
        }
        System.out.println("Student array cleared.");
    }

    /**
     * Determines whether a Student surname exists as a key inside the
     * associative array.
     *
     * @pre true
     * @param surname The student surname (key) to locate
     * @return true iff the surname exists as a key in the associative array
     */
    @Override
    public boolean containsSurname(String surname) {
        int probe = 1;
        int hash = hashFunc(surname, maxSize);
        System.out.println("finding " + surname + ", initial hash: " + hash);
        while (keys[hash] != null && students[hash].getActive()) {
            if (keys[hash] == surname && students[hash].getActive()) {
                System.out.println("Hash has been matched, student with surname " + keys[hash] + " is in the array.");
                return true;
            }
            hash = (hash + probe * probe++) % maxSize;
            System.out.println("hash did not match " + surname + " new hash: " + hash);
        }
        System.out.println("Hash has not been matched, student with surname " + surname + " is not in the array.");
        return false;
    }

    /**
     * Determines whether a Student object exists as a value inside the
     * associative array.
     *
     * @pre true
     * @param student The Student object to locate
     * @return true iff the Student object 'student' exists as a value in the
     * associative array
     */
    @Override
    public boolean containsValue(Student student) {
        int probe = 1;
        int hash = hashFunc(student.getSurname(), maxSize);
        System.out.println("finding " + student.getSurname() + ", initial hash: " + hash);
        while (students[hash] != null && students[hash].getActive()) {
            if (students[hash] == student && students[hash].getActive()) {
                System.out.println("Hash has been matched.");
                return true;
            }
            hash = (hash + probe * probe++) % maxSize;
            System.out.println("hash did not match" + student.getSurname() + " new hash: " + hash);
        }
        System.out.println("Hash has not been matched, student is not in the array.");
        return false;
    }

    /**
     * Returns a Student object mapped to the supplied surname.
     *
     * @pre true
     * @param surname The student surname (key) to locate
     * @return the Student object mapped to the key surname if the surname
     * exists as key in the associative array, otherwise null
     */
    @Override
    public Student getStudent(String surname) {
        int probe = 1;
        int hash = hashFunc(surname, maxSize);
        System.out.println("finding " + surname + ", initial hash: " + hash);
        while (keys[hash] != null && students[hash].getActive()) {
            if (keys[hash] == surname && students[hash].getActive()) {
                System.out.println("Hash has been matched, student with surname " + keys[hash] + " is in the array.");
                return students[hash];
            }
            hash = (hash + probe * probe++) % maxSize;
            System.out.println("hash did not match " + surname + " new hash: " + hash);
        }
        System.out.println("Hash has not been matched, student with surname " + surname + " is not in the array.");
        return null;
    }

    /**
     * Determines if the associative array is empty or not.
     *
     * @pre true
     * @return true iff the associative array is empty
     */
    @Override
    public boolean isEmpty() {
        boolean empty = true;
        int i = 0;
        do {
            if (keys[i] != null) {
                empty = false;
            }
            i++;
        } while (empty && i < maxSize);
        return empty;
    }

    /**
     * Returns a Set view of the surnames (keys) contained by the associative
     * array
     *
     * @pre true
     * @return a Set view of the surnames (keys) contained by the associative
     * array
     */
    @Override
    public Set<String> keySet() {
        Set keySet = new HashSet();
        for (int i = 0; i < maxSize; i++) {
            if (keys[i] != null && students[i].getActive()) {
                keySet.add(keys[i]);
            }
        }
        return keySet;
    }

    /**
     * Inserts a Student into the associative array, with the key of the
     * supplied Student's surname. Note: If the surname already exists as a key,
     * then then the original entry is overwritten. This method should return
     * the previous associated value if one exists, otherwise null
     *
     * @pre true
     */
    @Override
    public Student put(Student student) {
        String surname = student.getSurname();
        System.out.println("Adding student: " + student.getSurname() + "\n");
        int probe = 1;
        int hash = hashFunc(surname, maxSize);
        if (containsSurname(surname)) {
            while (keys[hash] != null) {
                if (keys[hash] == surname) {
                    Student oldStudent = students[hash];
                    keys[hash] = surname;
                    students[hash] = student;
                    return oldStudent;
                }
                hash = (hash + probe * probe++) % maxSize;
            }
        } else {
            while (keys[hash] != null && students[hash].getActive()) {
                System.out.println("Collision has occurred, " + surname + " old hash value: " + hash);
                hash = (hash + probe * probe++) % maxSize;
                System.out.println("new hash value attempt = " + hash);
            }
        }
        currentSize++;
        keys[hash] = surname;
        students[hash] = student;
        students[hash].setActive(true);
        System.out.println("\nAdded student: " + keys[hash] + " hash value: " + hash);
        System.out.println("New load factor: "+loadFactor());
        return null;
    }

    private int hashFunc(String surname, int size) {
        int hash = 1;
        for (int i = 0; i < surname.length(); i++) {
            hash = ((i + 43) + surname.charAt(i) * 7);
        }
        return hash % size;
    }

    /**
     * Removes and returns a Student from the associative array, with the key
     * the supplied surname.
     *
     * @param surname The surname (key) to remove.
     * @pre true
     * @return the removed Student object mapped to the surname, or null if the
     * surname does not exist.
     */
    @Override
    public Student remove(String surname) {
        if (containsSurname(surname)) {
            int probe = 1;
            int hash = hashFunc(surname, maxSize);
            System.out.println("Removing " + keys[hash]);
            while (keys[hash] != null) {
                if (keys[hash] == surname) {
                    students[hash].setActive(false);
                    currentSize--;
                    return students[hash];
                }
                hash = (hash + probe * probe++) % maxSize;
            }
        }
        return null;
    }

    /**
     * Returns the number of Students in the associative array
     *
     * @pre true
     * @return number of Students in the associative array. 0 if empty
     */
    public int size() {
        return currentSize;
    }

    public int maxSize() {
        return maxSize;
    }

    /**
     * Returns a Set view of the Students contained by the associative array
     *
     * @pre true
     * @return a Set view of Student objects contained by the associative array
     */
    public Set<Student> getStudents() {
        Set studentSet = new HashSet();
        for (int i = 0; i < maxSize; i++) {
            if (keys[i] != null && students[i].getActive()) {
                studentSet.add(students[i]);
            }
        }
        return studentSet;
    }

    public float loadFactor() {
        float loadFactor = (float)currentSize / maxSize;
        if (loadFactor > 0.75) {
            System.out.println("\nLoad factor is taking place, old max size: " + maxSize + "\n");
            Student[] newStudents = new Student[maxSize * 2];
            String[] newKeys = new String[maxSize * 2];
            int oldMax = maxSize;
            maxSize = maxSize * 2;
            for (int i = 0; i < oldMax; i++) {
                if (keys[i] != null) {
                    int newHash = hashFunc(keys[i], maxSize);
                    int oldHash = hashFunc(keys[i], maxSize);
                    int probe = 1;
                    while (newKeys[newHash] != null && newStudents[newHash].getActive()) {
                        System.out.println("collision");
                        newHash = (newHash + probe * probe++) % maxSize;
                    }
                    newKeys[newHash] = keys[i];
                    System.out.println(keys[i] + " old hash: " + oldHash + " new hash: " + newHash);
                    newStudents[newHash] = students[i];
                }
            }
            students = newStudents;
            keys = newKeys;
            System.out.println("\nLoad factor has taken place, new max size: " + maxSize + "\n");
            //System.out.println("New Key set: "+keySet());
            //System.out.println("New Student set: "+getStudents());
        } return loadFactor;
    }
}
