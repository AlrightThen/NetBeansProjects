/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package module;

//import java.util.ArrayList;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

//import java.util.List;
/**
 *
 * @author 16031521
 */
public class main {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StudentAssociativeArray studArray = new StudentAssociativeArray(4);
    Student Jenkins = new Student("JENKINS","Maths","fbvadkjjfh49");
    Student Will = new Student("WILLIAMSON","Computing","bdfs1389574");
    Student Simpson = new Student("SIMPSON","English","1346781gf");
    Student Norbert = new Student("NORBERT","Sociology","2r4y7734ht");
    studArray.put(Jenkins);
    studArray.put(Will);
    studArray.put(Simpson);
    studArray.put(Norbert);
    System.out.println(studArray.getStudents());
    System.out.println(studArray.keySet());
    studArray.containsSurname("JENKINS");
    studArray.getStudent("JENKINS");
        System.out.println("\n");
    studArray.clear();
        System.out.println("\n");
    studArray.containsSurname("JENKINS");
    studArray.getStudent("JENKINS");
    System.out.println(studArray.getStudents());
    System.out.println(studArray.keySet());


    }
}