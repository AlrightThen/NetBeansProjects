/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipsgui2;



//import javafx.event.ActionListener;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;
import java.util.Observer;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Text;
import javafx.scene.paint.Color;
import javafx.scene.shape.StrokeType;
import javafx.stage.Stage;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.ColumnConstraints;
import static javafx.scene.layout.GridPane.getColumnIndex;
import static javafx.scene.layout.GridPane.getRowIndex;
import javafx.scene.layout.RowConstraints;

/**
 *
 * @author 16031521
 */
public class BSView implements Observer {
    
    private static final int TILE_SIZE = 40;
    private static final char xSymbs[] = {'A','B','C','D','E','F','G','H','I','J'};
    
    private ArrayList<Tile> grid = new ArrayList<Tile>();
    
    private BSController controller;
    private Scene scene;
    private Stage stage;
    
    private GridPane gPane = new GridPane();
    private GridPane gPane2 = new GridPane();
    private boolean cheat = false;
    private boolean winMessage = false;
    
    public BSView(Stage stage) {
        this.stage = stage;
    }
    
    public void createContent() {
        Pane root = new Pane();
        root.setPrefSize(800,700);
        
        for (int i = 0; i < 16; i++) {
           ColumnConstraints column = new ColumnConstraints(75);
           ColumnConstraints column2 = new ColumnConstraints(180);
           RowConstraints row = new RowConstraints(50);
           gPane.getColumnConstraints().add(column);
           gPane2.getRowConstraints().add(row);
           if(i < 10) gPane.getRowConstraints().add(row);
           if(i < 5) gPane2.getColumnConstraints().add(column2);
        }
        
        Label messageLabel = new Label("Awaiting Actions...");
        gPane2.add(messageLabel,1,10);

        Button newGame = new Button("New Game");
        newGame.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                gPane.getChildren().remove(newGame);
                try {
                    newGame();
                } catch (Exception ex) {
                    Logger.getLogger(BSView.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        gPane.add(newGame,3,9);

        Button save = new Button("Save");
        save.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                try {
                    save();
                } catch (IOException ex) {
                    Logger.getLogger(BSView.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        gPane.add(save,5,9);

        Button load = new Button("Load");
        load.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                try {
                    load();
                } catch (IOException ex) {
                    Logger.getLogger(BSView.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        });
        gPane.add(load,6,9);

        Label title = new Label("Battleships Game");
        gPane2.add(title,2,0);
        
        Button cheatOn= new Button("Cheat ON");
        cheatOn.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                gPane.getChildren().remove(cheatOn);
                cheat();
            }
        });
        gPane.add(cheatOn,7,9);

        root.getChildren().add(gPane2);
        root.getChildren().add(gPane);
        for (Entity e : controller.getEntities()) {
            int x = e.getX();
            int y = e.getY();
            Tile tile = new Tile(x,y,' ');
            if(e.getHit()) {            
                switch (e.getType()){
                    case "ship part":
                            tile = new Tile(x,y,'O');
                        break;
                    case "water":
                            tile = new Tile(x,y,'X');
                        break;
                }
            }
            grid.add(tile);
            root.getChildren().add(tile);
        }
        scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
        update(controller,null);
        assert stage.getScene() == scene;
    }
    
    private void setMessageLabel (String text) {
        for (Node node : gPane2.getChildren()) {
            if (node instanceof Label && getColumnIndex(node) == 1 && getRowIndex(node) == 10) { //This error is meaningless and non existent, no variable "column" is related to this.
                ((Label) node).setText(text);
                assert ((Label) node).getText().equals(text);
                return;
            }
        }
    }
    
    private void cheat() {
        setMessageLabel("Cheating turned on!");
        cheat = true;
        update(controller,null);
        Button cheatOff = new Button("Cheat OFF");
        cheatOff.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                setMessageLabel("Cheating turned off!");
                Button cheatOn = new Button("Cheat ON");
                gPane.getChildren().remove(cheatOff);
                cheat = false;
                update(controller,null);
                cheatOn.setOnAction(new EventHandler<ActionEvent>() {
                    @Override public void handle(ActionEvent e) {
                        cheat();
                    }
                });
                gPane.add(cheatOn,7,9);
            }
        });
        gPane.add(cheatOff,7,9);
    }
    
    private void newGame() throws Exception {
        setMessageLabel("Creating new game...");
        Label messageLabel2 = new Label("Please enter parameters \nfor new game");
        Label messageLabel3 = new Label("Number of ships length 2 (0-3):");
        Label messageLabel4 = new Label("Number of ships length 1 (0-4):");
        TextField field1 = new TextField("2");
        TextField field2 = new TextField("0");
        Button confirmButton = new Button("Confirm");
        Button cancel = new Button("Cancel");
        
        gPane2.add(messageLabel2,2,10);
        gPane2.add(messageLabel3,1,11);
        gPane2.add(messageLabel4,1,12);
        gPane2.add(field1,2,11);
        gPane2.add(field2,2,12);
        gPane2.add(confirmButton,2,13);
        gPane2.add(cancel,3,13);
        confirmButton.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                try {
                if(controller.generateRoom(Integer.parseInt(field1.getText()), Integer.parseInt(field2.getText()))) {
                    winMessage = false;
                    Button newGame = new Button("New Game");
                    newGame.setOnAction(new EventHandler<ActionEvent>() {
                        @Override public void handle(ActionEvent e) {
                            gPane.getChildren().remove(newGame);
                            try {
                                newGame();
                            } catch (Exception ex) {
                                Logger.getLogger(BSView.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    });
                    gPane2.getChildren().remove(messageLabel2);
                    gPane2.getChildren().remove(messageLabel3);
                    gPane2.getChildren().remove(messageLabel4);
                    gPane2.getChildren().remove(field1);
                    gPane2.getChildren().remove(field2);
                    gPane2.getChildren().remove(confirmButton);
                    gPane2.getChildren().remove(cancel);
                    gPane.add(newGame,3,9);
                    setMessageLabel("New game created!");
                    update(controller,null);
                } else {
                     setMessageLabel("New game failed to create.\nMake sure values are between\n(0-4) and (0-3) respectively.");
                }
                } catch (NumberFormatException ex) {
                     setMessageLabel("New game failed to create.\nFields must be integers.");
                    
                }
            }
        });
        
        cancel.setOnAction(new EventHandler<ActionEvent>() {
            @Override public void handle(ActionEvent e) {
                Button newGame = new Button("New Game");
                    newGame.setOnAction(new EventHandler<ActionEvent>() {
                        @Override public void handle(ActionEvent e) {
                            gPane.getChildren().remove(newGame);
                            try {
                                newGame();
                            } catch (Exception ex) {
                                Logger.getLogger(BSView.class.getName()).log(Level.SEVERE, null, ex);
                            }
                        }
                    });
                    gPane2.getChildren().remove(messageLabel2);
                    gPane2.getChildren().remove(messageLabel3);
                    gPane2.getChildren().remove(messageLabel4);
                    gPane2.getChildren().remove(field1);
                    gPane2.getChildren().remove(field2);
                    gPane2.getChildren().remove(confirmButton);
                    gPane2.getChildren().remove(cancel);
                    gPane.add(newGame,3,9);
                    setMessageLabel("New game creation cancelled.");
                }
            });
        update(controller,null);
    }
    
    private void save() throws IOException {
        controller.save();
        setMessageLabel("Game saved!");
    }
    
    private void load() throws IOException {
        if(controller.load()) {
            update(controller,null);
            winMessage = false;
            setMessageLabel("Game loaded!");
        } else {
            setMessageLabel("Text file invalid,\ngame failed to load.");
        }
        
    }
    
    public void setController(BSController controller) {
        this.controller = controller;
        controller.generateRoom(2,0);
    }
    

    @Override
    public void update(Observable o, Object arg) {
        for(Tile tile : grid) {
            tile.update();
        }
    }

    
    
    private class Tile extends StackPane {
        private final int x,y;
        private Text text = new Text();
        
        private final Rectangle border = new Rectangle(TILE_SIZE - 2, TILE_SIZE -2);
        
        public Tile(int x, int y, char symb) {
            this.x = x;
            this.y = y;
            text.setText(Character.toString(symb));
            
            border.setStrokeType(StrokeType.OUTSIDE);
            border.setStroke(Color.BLACK);
            getChildren().addAll(border, text);

            setTranslateX(x*TILE_SIZE+200);
            setTranslateY(y*TILE_SIZE+50);
            update();
            
            setOnMouseClicked(e -> shoot());
        }
        
        public void shoot() {
            Entity e = controller.getEntity(x,y);
            setMessageLabel(controller.shoot(xSymbs[x], y));
            if(controller.getWin() && !winMessage) {
                System.out.println("victory");
                winMessage = true;
                setMessageLabel("You win!\nAll ships have been sunk!");
            }
        }
        
        public void update() {
            Entity e = controller.getEntity(x,y);
            if(e.getHit()) {
                switch (e.getType()) {
                    case "ship part":
                            text.setText("O");
                            border.setFill(Color.GREEN);
                        break;
                    case "water":
                            text.setText("X");
                            border.setFill(Color.RED);
                        break;
                }
            } else {
                if(cheat && e.getType() == "ship part") {
                    text.setText("S");
                    border.setFill(Color.PURPLE);
                    
                }
                else {
                    text.setText(" ");
                    border.setFill(Color.BLUE);
                }
                
            }
        }
    }
    
    /*@Override
    public void start(Stage stage) {
        Scene scene = new Scene(createContent());
        
        stage.setScene(scene);
        stage.show();
    }*/
}   
