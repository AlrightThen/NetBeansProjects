/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipsgui2;

import javafx.application.Application;
//import static javafx.application.Application.launch;
import javafx.stage.Stage;
//import javafx.stage.Stage;

/**
 *
 * @author 16031521
 */
public class main extends Application {
    
    @Override
    public void start(Stage stage) {
        BSModel model = new BSModel();
        BSView view = new BSView(stage);
        BSController controller = new BSController(model, view);
        view.setController(controller);
        controller.addObserver(view);
        view.createContent();
    }
    
    public static void main(String[] args) {
        launch(args);
    }

}
