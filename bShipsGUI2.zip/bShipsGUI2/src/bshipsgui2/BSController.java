/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipsgui2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Observable;

/**
 *
 * @author 16031521
 */
public class BSController extends Observable {
    
    private BSModel model;
    public BSController(BSModel model, BSView view) {
        this.model = model;
    }
    public Entity getEntity(int x, int y) {
        return model.getEntity(x,y);
    }
    public String shoot(char x, int y) {
        String msg = model.hit(x, y);
        sendUpdate();
        return msg;
    }
    public boolean generateRoom(int twoLength, int oneLength) {
        return model.generateRoom(twoLength, oneLength);
    }
    
    public void save() throws IOException {
        model.saveEntities();
        sendUpdate();
    }
    public boolean load() throws IOException {
        boolean loaded = model.loadEntities();
        sendUpdate();
        return loaded;
    }
    
    public ArrayList<Entity> getEntities() {
        return model.getEntities();
    }
    
    public boolean getWin() {
        boolean found = false;
        for(Ship i : model.getShips()) {
                if(!i.isDestroyed()) {
                    found = true;
                }
            }
        return !found;
    }
    
    private void sendUpdate() {
        setChanged();
        notifyObservers();
    }
}
    
