/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bshipsgui2;

/**
 *
 * @author 16031521
 */
public abstract class Entity {
    
    private int x;
    private int y;
    private boolean hit;
    private String type;
    
    public Entity(int x,int y) {
        this.x = x;
        this.y = y;
        hit = false;
        assert this.x == x && this.y == y;
    }
    
    public void setHit(boolean hit) {
        this.hit = hit;
        assert this.hit == hit;
    }
    
    public boolean getHit() {
        return hit;
    }
    
    public void setType(String type) {
        this.type = type;
        assert this.type == type;
    }
    
    public String getType() {
        return type;
    }
    
    public int getX() {
        return x;
    }
    public int getY() {
        return y;
    }
}
