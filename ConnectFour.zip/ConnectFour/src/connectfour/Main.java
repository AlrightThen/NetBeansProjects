/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour;

import java.util.Scanner;

/**
 *
 * @author 16031521
 */
public class Main { //added main class to enable the program to actually run.
    public static boolean winnerFound = false;
    public static int currentPlayer = 2;
    public static void main(String[] args) {
        ConnectFour connectfour = new ConnectFour();
        Scanner kb = new Scanner(System.in);
        connectfour.addAndFindWinner(2, 3);
        connectfour.displayGrid("Connect Four");
        while(!winnerFound) //Repeatedly asks the user to input connection locations until a winner is found, then stops the program
        {
            currentPlayer = changePlayer(currentPlayer); //Calls method to change which color block will be inputted next
            System.out.println("Player " + connectfour.playerName(currentPlayer) + " choose column");
            int i = kb.nextInt();
            int winner = connectfour.addAndFindWinner(currentPlayer, i); //This calls the method to add the block to the column chosen and check for a winner.
            connectfour.displayGrid("Connect Four");
            if(winner != 0)
            {
                winnerFound = true;
                System.out.println("Player " + connectfour.playerName(winner) + " wins!");
            }
        }
    }
    private static int changePlayer(int player) { //method to change color block
        int newPlayer = 0;
        if(player == 2) {
            newPlayer = 1;
        }
        else if (player == 1) {
            newPlayer = 2;
        }
        return newPlayer;
    }
}
