/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package connectfour;

/**
 *
 * @author D Lightfoot 2017-10-11
 * WITH DELIBERATE ERRORS! (testing exercise)
 */
public class ConnectFour {

    public static final int NUMCOLUMNS = 7; // across
    public static final int NUMROWS = 6; // down

    public static final int NOPLAYER = 0;
    public static final int RED = 1;
    public static final int YELLOW = 2;
    // arbitrary coding, but these three must all be different

    private int[][] grid; // 0..NUMCOLUMNS-1 by 0..NUMROWS-1
    private int[] columnHeight;

    private int previousPlayer;

    public ConnectFour() {
        previousPlayer = NOPLAYER;
        grid = new int[NUMCOLUMNS][NUMROWS];
        columnHeight = new int[NUMCOLUMNS];

        for (int col = 0; col != NUMCOLUMNS; col++) {
            for (int row = 0; row != NUMROWS; row++) {
                grid[col][row] = NOPLAYER;
            }
        }
        for (int i = 0; i != NUMCOLUMNS; i++) {
            columnHeight[i] = 0;
        }
    }  // END ConnectFour

    public int addAndFindWinner(int player, int col) {
        // adds player in col and returns winner or NOPLAYER
        System.out.println("Add " + playerName(player) + " to " + col);

        assert (player == RED || player == YELLOW) && player != previousPlayer;
        // players have sensible colour and players are alternating
        assert 0 <= col && col < NUMCOLUMNS;
        //  column in range
        assert columnHeight[col] != NUMROWS;
        // column is not full

        previousPlayer = player;

        int topFreeRow = columnHeight[col];
        grid[col][topFreeRow] = player;
        columnHeight[col]++;

        int winner = determineWinner(player, col);
        return winner;
    } // END addAndFindWinner

    public void displayGrid(String title) {
        // displays the grid with title above
        System.out.println(title);
        System.out.println("    0 1 2 3 4 5 6");
        int cellValue;
        for (int row = NUMROWS - 1; row != -1; row--) {
            System.out.print(row + " ");
            System.out.print("  ");

            for (int col = 0; col != NUMCOLUMNS; col++) {
                cellValue = grid[col][row];
                if (cellValue == RED) {
                    System.out.print("R ");
                } else if (cellValue == YELLOW) {
                    System.out.print("Y ");
                } else {
                    System.out.print("_ ");
                }
            }
            System.out.println();
        }
    }// END displayGrid

    private int numVertical(int player, int col) {
        // to be called when a player has been added here
        // return this player as winner if this cell is of this player's colour 
        // and there are at least four adjacent of this colour in this column

        assert player == RED || player == YELLOW;
        // player has sensible colour
        assert 0 <= col && col < NUMCOLUMNS;
        //  column in range

        int numMatching = 0;
        int r = columnHeight[col] - 1; // top row of column col
        while (r >= 0 && grid[col][r] == player) {
            numMatching++;
            r--;
        } // r < 0 || grid[col][r] != player

        return numMatching;
    } // END numVertical

    private int numForwardDiagonal(int player, int col) {
        // forward /
        // to be called when a player has been added here
        // return number of same on forward diagonal 

        assert player == RED || player == YELLOW;
        // player has sensible colour
        assert 0 <= col && col < NUMCOLUMNS;
        //  column in range

        int numMatching = 0;
        int r = columnHeight[col] - 1;
        int c = col;
        while (c >= 0 && r >= 0 && grid[c][r] == player) {
            numMatching++;
            c--;
            r--;
        } // c < 0 || r < 0 || grid[c][r] != player
        
        if(col != NUMCOLUMNS - 1 && columnHeight[col] != NUMROWS) //added an if condition to make sure that c != NUMCOLUMNS and r != NUMROWS in the next line
        {
        c = col+1;
        r = columnHeight[col];
        while (c < NUMCOLUMNS && r < NUMROWS && grid[c][r] == player) {
            numMatching++;
            c++;
            r++;
        } // c >= NUMCOLUMNS || r >= NUMROWS || grid[c][r] != player
        }
        return numMatching;
    } // END numForwardDiagonal

    private int numBackwardDiagonal(int player, int col) {
        // backward \
        // to be called when a player has been added here
        // return number of same on backward diagonal 

        assert player == RED || player == YELLOW;
        // player has sensible colour
        assert 0 <= col && col < NUMCOLUMNS;
        //  column in range 

        int numMatching = 0;
        int r = columnHeight[col] - 1;
        int c = col;
        while (c < NUMCOLUMNS && r >= 0 && grid[c][r] == player) { //Edited so its column increasing, row decreasing first
            numMatching++;
            c++;
            r--;
        } // c < 0 || r >= NUMROWS || grid[c][r] != player
        if(columnHeight[col] != NUMROWS && col != 0) //This second while loop has been edited so that it is the reverse of the first while loop, where it counts down from the columns and counts up with the rows.
        {
        c = col - 1;
        r = columnHeight[col];
        while (c >= 0 && r < NUMROWS && grid[c][r] == player) {
            numMatching++;
            c--;
            r++;
        } // c >= NUMCOLUMNS || r >= NUMROWS || grid[c][r] != player
        }

        return numMatching;
    }// END numBackwardDiagonal

    private int numHorizontal(int player, int col) {
        // to be called when a piece for player has been added in col
        // returns number of player colour in this row

        assert player == RED || player == YELLOW;
        // player has sensible colour
        assert 0 <= col && col < NUMCOLUMNS;
        //  column in range

        int numMatching = 0;
        int r = columnHeight[col] - 1;
        int c = col;
        while (c >= 0 && grid[c][r] == player) {
            numMatching++;
            c--;
        } // c < 0 || grid[c][r] != player
        if(col != NUMCOLUMNS - 1) //added an if condition to make sure that c != NUMCOLUMNS in the next line
        {
        c = col+1; //changed to col+1 because when it goes for the second loop, the program counts the start column counting twice
        while (c < NUMCOLUMNS && grid[c][r] == player) {
            numMatching++;
            c++;
        } // c >= NUMCOLUMNS || grid[c][r] != player
        }
        return numMatching;
    } // END numHorizontal

    private int determineWinner(int player, int col) {
        // to be called when a player has been added here
        int winner = NOPLAYER;
        int numVerticalMatching, numHorizontalMatching,
                numForwardMatching, numBackwardMatching;

        assert player == RED || player == YELLOW;
        // player must have sensible colour
        assert 0 <= col && col < NUMCOLUMNS;
        //  column must be in range

        numVerticalMatching = this.numVertical(player, col);
        if (numVerticalMatching >= 4) {
            winner = player;
        } else {
            numHorizontalMatching = this.numHorizontal(player, col);
            if (numHorizontalMatching >= 4) {
                winner = player;
            } else {
                numForwardMatching = this.numForwardDiagonal(player, col);
                if (numForwardMatching >= 4) {
                    winner = player;
                } else {
                    numBackwardMatching = this.numBackwardDiagonal(player, col);
                    if (numBackwardMatching >= 4) {
                        winner = player;
                    }
                }
            }
        }
        return winner;
    } // END determineWinner

    public String playerName(int player) {
        assert player == NOPLAYER || player == RED || player == YELLOW;
        String name = "";
        if (player == NOPLAYER) {
            name = "No player";
        } else if (player == RED) {
            name = "Red";
        } else if (player == YELLOW) {
            name = "Yellow";
        }
        return name;
    } // END playerName

} // END  ConnectFour